using UnityEngine;
using NonsensicalKit.Simulation.WarehouseSimulation.Allocation;
using NonsensicalKit.Simulation.WarehouseSimulation.Core;
using NonsensicalKit.Simulation.WarehouseSimulation.Model;
using NonsensicalKit.Simulation.WarehouseSimulation.Playback;

namespace NonsensicalKit.Simulation.WarehouseSimulation.Runtime
{
    public sealed partial class JointControllerStackerJobRigPlayback
    {
        /// <summary>
        /// 旧路径会 Calibrate JointController.InitialValue；新驱动用世界对齐，这里只保证驱动节点就绪。
        /// </summary>
        private void CalibrateJointInitialValues()
        {
            EnsureDriver();
        }

        private void ApplyPartialGrid(int column, int level, int row)
        {
            if (!TryBuildCarriageJointValues(level, row, out var carriage))
            {
                return;
            }

            // 列向落在货叉关节上。只改排/层会把车留在场景静止位的 Z，料箱却按货位索引瞬移。
            var axes = carriage;
            if (column != _railColumn
                && TryBuildFullJointValues(column, level, row, out var extended))
            {
                axes = extended;
            }

            TryApplyAxisValues(in axes, 0f, StackerAxisMask.All);
            _storageColumn = column;
            _level = level;
            _row = row;
        }

        private static StackerAxisValueResolver.StackerAxisValues LerpAxisValues(
            in StackerAxisValueResolver.StackerAxisValues from,
            in StackerAxisValueResolver.StackerAxisValues to,
            float progress) =>
            LerpAxisValues(from, to, progress, progress, progress);

        private static StackerAxisValueResolver.StackerAxisValues LerpAxisValues(
            in StackerAxisValueResolver.StackerAxisValues from,
            in StackerAxisValueResolver.StackerAxisValues to,
            float levelProgress,
            float rowProgress) =>
            LerpAxisValues(from, to, levelProgress, rowProgress, Mathf.Max(levelProgress, rowProgress));

        private static StackerAxisValueResolver.StackerAxisValues LerpAxisValues(
            in StackerAxisValueResolver.StackerAxisValues from,
            in StackerAxisValueResolver.StackerAxisValues to,
            float levelProgress,
            float rowProgress,
            float forkProgress)
        {
            levelProgress = Mathf.Clamp01(levelProgress);
            rowProgress = Mathf.Clamp01(rowProgress);
            forkProgress = Mathf.Clamp01(forkProgress);
            return new StackerAxisValueResolver.StackerAxisValues(
                Mathf.Lerp(from.Level, to.Level, levelProgress),
                Mathf.Lerp(from.Row, to.Row, rowProgress),
                Mathf.Lerp(from.Fork, to.Fork, forkProgress));
        }

        private bool TryApplyAxisValues(in StackerAxisValueResolver.StackerAxisValues axes) =>
            TryApplyAxisValues(in axes, 0f, StackerAxisMask.All);

        private bool TryApplyAxisValues(
            in StackerAxisValueResolver.StackerAxisValues axes,
            float duration) =>
            TryApplyAxisValues(in axes, duration, StackerAxisMask.All);

        /// <summary>
        /// 把 .dat 轴向标量 L/R/F 合成仓库局部 → 世界坐标，再交给 StackerTransformDriver。
        /// 双库里列沿 Z，而货叉关节的世界方向就是 Z，巷道走行必须带动货叉关节。
        /// 掩码若去掉 Fork，车会停在预制体静止位，料箱却被摆到货位索引上。
        /// </summary>
        private bool TryApplyAxisValues(
            in StackerAxisValueResolver.StackerAxisValues axes,
            float duration,
            StackerAxisMask mask)
        {
            if (!EnsureDriver() || _positionIndex == null)
            {
                return false;
            }

            if (!TryComposeAxisWorld(in axes, out var world))
            {
                return false;
            }

            return m_transformDriver.MoveAlignToWorld(world, duration, mask);
        }

        private bool TryComposeAxisWorld(
            in StackerAxisValueResolver.StackerAxisValues axes,
            out Vector3 world)
        {
            world = default;
            var positions = _positionIndex.Positions;
            if (positions == null)
            {
                return false;
            }

            var mapping = SlotLocalAxisMappingCache.Resolve(positions);
            var local = Vector3.zero;
            local[mapping.LevelAxis] = axes.Level;
            local[mapping.RowAxis] = axes.Row;
            local[mapping.ForkAxis] = axes.Fork;
            return _positionIndex.TryLocalToWorld(local, out world);
        }

        private bool TryApplyCarriageLerp(
            int fromLevel,
            int fromRow,
            int fromRailColumn,
            int toLevel,
            int toRow,
            int toRailColumn,
            float progress,
            float duration,
            bool commitState) =>
            TryApplyCarriageLerp(
                fromLevel,
                fromRow,
                fromRailColumn,
                toLevel,
                toRow,
                toRailColumn,
                progress,
                progress,
                duration,
                commitState);

        private bool TryApplyCarriageLerp(
            int fromLevel,
            int fromRow,
            int fromRailColumn,
            int toLevel,
            int toRow,
            int toRailColumn,
            float levelProgress,
            float rowProgress,
            float duration,
            bool commitState)
        {
            if (fromLevel == toLevel && fromRow == toRow && fromRailColumn == toRailColumn)
            {
                if (TryBuildCarriageJointValues(toLevel, toRow, toRailColumn, out var sameAxes)
                    && TryApplyAxisValues(in sameAxes, duration, StackerAxisMask.All))
                {
                    if (commitState)
                    {
                        _storageColumn = toRailColumn;
                        _level = toLevel;
                        _row = toRow;
                    }

                    return true;
                }
            }

            if (!TryBuildCarriageJointValues(fromLevel, fromRow, fromRailColumn, out var fromAxes)
                || !TryBuildCarriageJointValues(toLevel, toRow, toRailColumn, out var toAxes))
            {
                LogMotionResolveSkipOnce(
                    $"Carriage L{fromLevel}R{fromRow}→L{toLevel}R{toRow} rail={toRailColumn}");
                return false;
            }

            // 收回值里的 Fork 是这一列的巷道中心，不是货格深处。三轴一起对齐才会沿 Z 开到该列。
            var forkProgress = Mathf.Max(levelProgress, rowProgress);
            var axes = LerpAxisValues(fromAxes, toAxes, levelProgress, rowProgress, forkProgress);
            if (!TryApplyAxisValues(in axes, duration, StackerAxisMask.All))
            {
                return false;
            }

            if (commitState)
            {
                _storageColumn = toRailColumn;
                _level = toLevel;
                _row = toRow;
            }

            return true;
        }

        private bool TryApplyFullLerp(
            int fromColumn,
            int fromLevel,
            int fromRow,
            int toColumn,
            int toLevel,
            int toRow,
            float progress,
            bool commitState,
            bool toUsesForkDepth = false,
            float toForkDepthMeters = 0f,
            bool fromUsesForkDepth = false,
            float fromForkDepthMeters = 0f,
            bool fromTreatRailColumnAsCarriage = true,
            bool toTreatRailColumnAsCarriage = true)
        {
            // 伸叉/收叉按两端的世界坐标插值。相对静止位加一小段伸缩，到不了另一列的 Z。
            if (!TryBuildEndpointJointValues(
                    fromColumn,
                    fromLevel,
                    fromRow,
                    fromUsesForkDepth,
                    fromForkDepthMeters,
                    out var fromAxes,
                    treatRailColumnAsCarriage: fromTreatRailColumnAsCarriage && !fromUsesForkDepth)
                || !TryBuildEndpointJointValues(
                    toColumn,
                    toLevel,
                    toRow,
                    toUsesForkDepth,
                    toForkDepthMeters,
                    out var toAxes,
                    treatRailColumnAsCarriage: toTreatRailColumnAsCarriage && !toUsesForkDepth))
            {
                LogMotionResolveSkipOnce(
                    $"Full C{fromColumn}L{fromLevel}R{fromRow}→C{toColumn}L{toLevel}R{toRow}");
                return false;
            }

            var axes = LerpAxisValues(fromAxes, toAxes, Mathf.Clamp01(progress));
            if (m_transformDriver != null)
            {
                m_transformDriver.StopMotion();
            }

            if (!TryApplyAxisValues(in axes, 0f, StackerAxisMask.All))
            {
                return false;
            }

            if (commitState)
            {
                _storageColumn = toColumn;
                _level = toLevel;
                _row = toRow;
            }

            return true;
        }

        private void SnapCarriage(int level, int row)
        {
            if (!TryBuildCarriageJointValues(level, row, out var axes))
            {
                return;
            }

            TryApplyAxisValues(in axes, 0f, StackerAxisMask.All);
            _storageColumn = _railColumn;
            _level = level;
            _row = row;
        }

        /// <summary>停在这一列的巷道中心。货叉关节对齐到该列世界坐标，不回到预制体静止位。</summary>
        private void SnapRetractedCarriage(int level, int row) => SnapCarriage(level, row);

        private void SnapRetractedPickup(in StackerJobPlaybackTask task)
        {
            if (TryGetPickupNodeFromJob(in task, out var node))
            {
                SnapRetractedCarriage(Mathf.Max(0, node.PickupLevel), node.PickupRow);
                return;
            }

            if (TryResolveTargetGrid(in task, out var pickup, task.IsOutbound))
            {
                SnapRetractedCarriage(pickup.Level, pickup.Row);
            }
        }

        private void SnapFork(int column, int level, int row)
        {
            var clampedColumn = StackerColumnReachUtility.ClampColumn(ActiveDefinition, column);
            ApplyPartialGrid(clampedColumn, level, row);
        }

        private void SnapToGrid(GridIndex slot) => SnapPartial(slot);

        private void SnapToHomePose()
        {
            _activeAisleLeftColumn = _definition.AisleLeftColumn;
            _railColumn = _activeAisleLeftColumn;
            _storageColumn = _railColumn;
            _level = 0;
            _row = 0;
            ClearHeldFork();
            CalibrateJointInitialValues();
            // 回原点停在巷道中心收回位，不要 Absolute 伸到左列货位。
            SnapRetractedCarriage(0, 0);
        }

        private void SnapPartial(GridIndex slot) =>
            SnapPartial(slot.Column, slot.Level, slot.Row);

        private void SnapPartial(int column, int level, int row)
        {
            var clampedColumn = StackerColumnReachUtility.ClampColumn(ActiveDefinition, column);
            ApplyPartialGrid(clampedColumn, level, row);
        }

        private bool TryBuildFullJointValues(int column, int level, int row, out StackerAxisValueResolver.StackerAxisValues axes)
        {
            return StackerAxisValueResolver.TryResolveAbsoluteValues(
                _positionIndex.Positions,
                _railColumn,
                new GridIndex(level, column, row),
                out axes);
        }

        private bool TryBuildEndpointJointValues(
            int column,
            int level,
            int row,
            bool useForkDepth,
            float forkDepthMeters,
            out StackerAxisValueResolver.StackerAxisValues axes,
            bool treatRailColumnAsCarriage = false)
        {
            if (useForkDepth)
            {
                return StackerAxisValueResolver.TryResolvePickupForkValues(
                    _positionIndex.Positions,
                    _railColumn,
                    level,
                    row,
                    _activeAisleLeftColumn,
                    forkDepthMeters,
                    out axes);
            }

            // GridIndex 列号==轨道列有两种含义：
            // - CarriagePose：货叉收回（巷道中心）→ treatRailColumnAsCarriage=true
            // - ForkPose 伸到左浅位：目标列恰好等于巷道左列 → Absolute 伸到该列
            // 放货若把终点也当成收回，会看不见朝左伸叉，或从左列扫向正方向。
            if (treatRailColumnAsCarriage && column == _railColumn)
            {
                return TryBuildCarriageJointValues(level, row, out axes);
            }

            return TryBuildFullJointValues(column, level, row, out axes);
        }

        private bool TryBuildCarriageJointValues(
            int level,
            int row,
            int railColumn,
            out StackerAxisValueResolver.StackerAxisValues axes)
        {
            return StackerAxisValueResolver.TryResolveCarriageValues(
                _positionIndex.Positions,
                railColumn,
                new GridIndex(level, railColumn, row),
                out axes);
        }

        private bool TryBuildCarriageJointValues(int level, int row, out StackerAxisValueResolver.StackerAxisValues axes) =>
            TryBuildCarriageJointValues(level, row, _railColumn, out axes);

        private void LogMotionResolveSkipOnce(string detail)
        {
            if (_loggedMotionResolveSkip)
            {
                return;
            }

            _loggedMotionResolveSkip = true;
            SimPlaybackLog.Warn(
                $"JointStackerRig 堆垛机 {m_stackerId} 无法解析关节目标（{detail}），" +
                "请检查仓库数据或货位坐标索引是否就绪。",
                this);
        }
    }
}
