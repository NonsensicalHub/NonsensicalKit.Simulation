using UnityEngine;
using NonsensicalKit.Simulation.WarehouseSimulation.Allocation;
using NonsensicalKit.Simulation.WarehouseSimulation.Model;
using NonsensicalKit.Simulation.WarehouseSimulation.Playback;

namespace NonsensicalKit.Simulation.WarehouseSimulation.Runtime
{
    public sealed partial class JointControllerStackerJobRigPlayback
    {
        private void AttachCargoByJob(int jobId)
        {
            if (_cargoRegistry == null)
            {
                return;
            }

            // TryGet 优先：避免 Acquire 反复 EnsureDetached 把已挂在叉上的货扯掉。
            if (!_cargoRegistry.TryGet(jobId, out var cargo) || cargo == null)
            {
                cargo = _cargoRegistry.Acquire(jobId);
            }

            if (cargo == null)
            {
                return;
            }

            var mount = ResolveCargoMount();
            if (mount == null)
            {
                return;
            }

            cargo.gameObject.SetActive(true);
            _cargoRegistry.UnparkJob(jobId);
            if (cargo.parent != mount)
            {
                // worldPositionStays：伸叉到位时货在取货点，绑上后随叉收回。
                cargo.SetParent(mount, true);
            }
        }

        private void ReleaseCargoByJob(int jobId) => _cargoRegistry?.Release(jobId);

        /// <summary>
        /// 取货提交前料箱还不在货叉上。回退到等待/驶近时要撤掉已经挂上的料箱。
        /// </summary>
        private void ReconcileCargoBeforePick(in StackerJobPlaybackTask task)
        {
            if (task.IsOutbound)
            {
                ReleaseCargoByJob(task.JobId);
            }
            else
            {
                DetachCargoKeepWorld(task.JobId);
            }
        }

        /// <summary>
        /// 取货提交以 <see cref="SimSubTaskKinds.StackerForkCargoAttachProgress"/> 为准，不依赖某一帧正好落在伸叉末端。
        /// 出库提交前货位由货架渲染，场景料箱必须收回；入库提交前料箱在取货点，只解除货叉挂载。
        /// </summary>
        private void ReconcilePickCargo(in StackerJobPlaybackTask task, float progress)
        {
            if (progress < SimSubTaskKinds.StackerForkCargoAttachProgress)
            {
                ReconcileCargoBeforePick(in task);
                return;
            }

            AttachCargoByJob(task.JobId);
        }

        /// <summary>
        /// 放货提交后：入库把料箱留在货叉当时的世界坐标；出库解除挂载，留给输送线摆到交互点。
        /// </summary>
        private void ReconcilePlaceCargo(
            in StackerJobPlaybackTask task,
            float progress,
            in SimSubTask placeSubTask)
        {
            BeginPlaceCargoDiag(task.JobId);
            var committed = progress >= SimSubTaskKinds.StackerForkCargoAttachProgress;
            if (!committed)
            {
                _placeDiagCommitted = false;
                LogPlaceCargoStarted(in task, progress, in placeSubTask);
                AttachCargoByJob(task.JobId);
                return;
            }

            if (task.IsOutbound)
            {
                DetachCargoKeepWorld(task.JobId);
            }
            else
            {
                var visual = placeSubTask.HasStackerPose ? placeSubTask.StackerToSlot : task.TargetSlot;
                PlaceCargoAtSlotByJob(task.JobId, task.TargetSlot, visual);
                LogPlaceCargoCommitted("放货提交", in task, visual, in placeSubTask, placeSubTask.HasStackerPose);
            }

            if (task.IsOutbound)
            {
                LogPlaceCargoCommitted("出库放货", in task, placeSubTask.StackerToSlot, in placeSubTask, placeSubTask.HasStackerPose);
            }
        }

        private void BeginPlaceCargoDiag(int jobId)
        {
            if (_placeDiagJobId == jobId)
            {
                return;
            }

            _placeDiagJobId = jobId;
            _placeDiagStarted = false;
            _placeDiagCommitted = false;
        }

        private void LogPlaceCargoStarted(in StackerJobPlaybackTask task, float progress, in SimSubTask placeSubTask)
        {
            if (_placeDiagStarted)
            {
                return;
            }

            _placeDiagStarted = true;
            SimPlaybackLog.CargoSync(
                $"放货开始 t={_logSimTime:F3} stacker={m_stackerId} job={task.JobId} 出库={task.IsOutbound} " +
                $"progress={progress:F3} 占用货位={task.TargetSlot} 放货姿态={placeSubTask.StackerToSlot} " +
                $"起点={placeSubTask.StackerFromSlot} rail={placeSubTask.StackerRailColumn} " +
                $"段={placeSubTask.StartSimTime:F3}-{placeSubTask.EndSimTime:F3} 货叉={FormatForkWorld()} " +
                DescribePositionIndex(),
                this);
        }

        private void LogPlaceCargoCommitted(
            string phase,
            in StackerJobPlaybackTask task,
            GridIndex visualSlot,
            in SimSubTask placeSubTask,
            bool hasPose)
        {
            if (_placeDiagJobId != task.JobId)
            {
                _placeDiagJobId = task.JobId;
                _placeDiagStarted = false;
                _placeDiagCommitted = false;
            }

            if (_placeDiagCommitted)
            {
                return;
            }

            _placeDiagCommitted = true;
            var cargoWorld = "无料箱";
            if (_cargoRegistry != null && _cargoRegistry.TryGet(task.JobId, out var cargo) && cargo != null)
            {
                cargoWorld = cargo.position.ToString("F2");
            }

            var visualWorld = DescribeWorld(visualSlot);
            var occupancyWorld = DescribeWorld(task.TargetSlot);
            var pose = hasPose
                ? $"起点={placeSubTask.StackerFromSlot} 终点={placeSubTask.StackerToSlot} rail={placeSubTask.StackerRailColumn} 段={placeSubTask.StartSimTime:F3}-{placeSubTask.EndSimTime:F3}"
                : "无放货姿态";
            SimPlaybackLog.CargoSync(
                $"{phase} t={_logSimTime:F3} stacker={m_stackerId} job={task.JobId} 出库={task.IsOutbound} " +
                $"占用货位={task.TargetSlot}({occupancyWorld}) 显示货位={visualSlot}({visualWorld}) {pose} " +
                $"货叉={FormatForkWorld()} 料箱={cargoWorld} 存储货位={IsStorageSlot(task.TargetSlot)} " +
                $"已停放={_cargoRegistry != null && _cargoRegistry.IsJobParked(task.JobId)} {DescribePositionIndex()}",
                this);
        }

        private string FormatForkWorld()
        {
            var mount = ResolveCargoMount();
            return mount != null ? mount.position.ToString("F2") : "无挂点";
        }

        private string DescribeWorld(GridIndex slot)
        {
            if (_positionIndex == null)
            {
                return "无索引";
            }

            return _positionIndex.TryGetWorldPosition(slot, out var world)
                ? world.ToString("F2")
                : "查不到坐标";
        }

        private string DescribePositionIndex()
        {
            if (_positionIndex == null)
            {
                return "索引=无";
            }

            var manager = _positionIndex.BoundManager != null ? _positionIndex.BoundManager.name : "无管理器";
            return $"索引仓库={_positionIndex.WarehouseId} 管理器={manager}";
        }

        /// <summary>出库放货：伸叉到位后解绑，料箱留在当前世界坐标，叉空载收回。</summary>
        private void DetachCargoKeepWorld(int jobId)
        {
            if (_cargoRegistry == null || !_cargoRegistry.TryGet(jobId, out var cargo))
            {
                return;
            }

            cargo.SetParent(null, true);
            cargo.gameObject.SetActive(true);
        }

        private void PlaceCargoAtSlotByJob(int jobId, GridIndex occupancySlot) =>
            PlaceCargoAtSlotByJob(jobId, occupancySlot, occupancySlot);

        /// <summary>
        /// 伸叉提交帧被跳过时，把已经到期的入库料箱补停到货位上。
        /// 已经停着的不动。调用方要先确认该货位在当前时刻仍然占用。
        /// </summary>
        public void EnsureInboundCargoParked(
            int jobId,
            GridIndex occupancySlot,
            GridIndex visualSlot,
            in SimSubTask placeSubTask,
            double simTime)
        {
            if (jobId < 0 || (_cargoRegistry != null && _cargoRegistry.IsJobParked(jobId)))
            {
                return;
            }

            _logSimTime = simTime;
            PlaceCargoAtSlotByJob(jobId, occupancySlot, visualSlot);
            var task = new StackerJobPlaybackTask
            {
                JobId = jobId,
                StackerId = m_stackerId,
                TargetSlot = occupancySlot,
                IsOutbound = false,
            };
            LogPlaceCargoCommitted("放货补交", in task, visualSlot, in placeSubTask, placeSubTask.HasStackerPose);
        }

        /// <summary>
        /// 入库放货不回收场景料箱，也不交给货架 GPU。
        /// 货架按整仓重建，60 倍速下会晚于关节很多；货位仓库号为 0 时同一列号还会画到另一座库，看起来像邻巷两列。
        /// 坐标用本机货位索引上的放货姿态（与货叉同一套），倍速跳帧收了一截叉也不会把箱子留在半空。
        /// </summary>
        private void PlaceCargoAtSlotByJob(int jobId, GridIndex occupancySlot, GridIndex visualSlot)
        {
            if (_cargoRegistry == null)
            {
                return;
            }

            if (!IsStorageSlot(occupancySlot))
            {
                if (!_cargoRegistry.TryGet(jobId, out var loose) || loose == null)
                {
                    return;
                }

                loose.SetParent(null, true);
                if (_positionIndex != null && _positionIndex.TryGetWorldPosition(visualSlot, out var looseWorld))
                {
                    loose.position = looseWorld;
                }

                loose.gameObject.SetActive(true);
                _cargoRegistry.ParkJob(jobId, occupancySlot);
                return;
            }

            var cargo = _cargoRegistry.Acquire(jobId);
            if (cargo == null)
            {
                return;
            }

            cargo.SetParent(null, true);
            if (_positionIndex != null
                && (_positionIndex.TryGetWorldPosition(visualSlot, out var world)
                    || _positionIndex.TryGetWorldPosition(occupancySlot, out world)))
            {
                cargo.position = world;
            }

            cargo.gameObject.SetActive(true);
            _cargoRegistry.ParkJob(jobId, occupancySlot);
        }

        /// <summary>
        /// 挂点优先级：Inspector 料箱挂载点 → 驱动货叉轴 → 驱动排向轴。
        /// </summary>
        private Transform ResolveCargoMount()
        {
            if (m_cargoMount != null)
            {
                return m_cargoMount;
            }

            if (EnsureDriver())
            {
                if (m_transformDriver.ForkAxis != null)
                {
                    return m_transformDriver.ForkAxis;
                }

                if (m_transformDriver.RowAxis != null)
                {
                    return m_transformDriver.RowAxis;
                }
            }

            return null;
        }

        private bool IsStorageSlot(GridIndex slot) =>
            _grid == null
            || SlotGridUtility.IsStorageSlot(_grid, slot.Level, slot.Column, slot.Row, _exclusionZones);
    }
}
