using System;
using NaughtyAttributes;
using NonsensicalKit.DigitalTwin;
using UnityEngine;

namespace NonsensicalKit.Simulation.WarehouseSimulation.Runtime
{
    /// <summary>堆垛机自由度掩码：只允许掩码内的轴沿自身滑轨移动。</summary>
    [Flags]
    public enum StackerAxisMask
    {
        None = 0,
        Row = 1 << 0,
        Level = 1 << 1,
        Fork = 1 << 2,
        Carriage = Row | Level,
        All = Row | Level | Fork,
    }

    /// <summary>
    /// 堆垛机三轴滑轨。每个轴节点的 localPosition 永远是「静止姿态 + 沿 Dir 的一个标量」，
    /// 其余分量锁在静止位，节点不会斜着平移。
    /// 对齐时按父子顺序走：先排、再层、再叉。动完一轴后，下一轴只吃剩余误差在自己世界方向上的投影。
    /// 不移动堆垛机根节点。
    /// </summary>
    public sealed class StackerTransformDriver : MonoBehaviour
    {
        [Header("三轴节点（显式优先）")]
        [Label("排向轴")]
        [SerializeField]
        private Transform m_rowAxis;

        [Label("层向轴")]
        [SerializeField]
        private Transform m_levelAxis;

        [Label("货叉轴（插）")]
        [SerializeField]
        private Transform m_forkAxis;

        [Header("各轴运动的局部方向（只改 localPosition 的这一分量）")]
        [Label("排向 Dir")]
        [SerializeField]
        private JointDirType m_rowDir = JointDirType.X;

        [Label("层向 Dir")]
        [SerializeField]
        private JointDirType m_levelDir = JointDirType.Z;

        [Label("货叉 Dir")]
        [SerializeField]
        private JointDirType m_forkDir = JointDirType.Y;

        [Header("对齐参考点")]
        [Label("对齐参考（空=货叉轴）")]
        [Tooltip("应对准货位中心的点，须是对应轴节点自身或其子节点，轴滑动才会带动它。空则用货叉轴。")]
        [SerializeField]
        private Transform m_alignReference;

        [Header("可选：从旧 JointController 自动填节点")]
        [Label("旧 JointController（仅迁移用）")]
        [Tooltip("三轴引用为空时，按 Joints[0]=排、[1]=层、[2]=插 取节点、Dir 和 ZeroState。运行时不调用 ChangeState。")]
        [SerializeField]
        private JointController m_legacyJointController;

        private bool _legacyTried;
        private bool _restReady;
        private Vector3 _rowRest;
        private Vector3 _levelRest;
        private Vector3 _forkRest;

        private float _rowFrom;
        private float _rowTo;
        private float _levelFrom;
        private float _levelTo;
        private float _forkFrom;
        private float _forkTo;
        private bool _rowFree;
        private bool _levelFree;
        private bool _forkFree;
        private float _moveDuration;
        private float _moveElapsed;
        private bool _moving;

        public Transform RowAxis => m_rowAxis;
        public Transform LevelAxis => m_levelAxis;
        public Transform ForkAxis => m_forkAxis;
        public JointDirType RowDir => m_rowDir;
        public JointDirType LevelDir => m_levelDir;
        public JointDirType ForkDir => m_forkDir;

        public Transform AlignReference
        {
            get
            {
                if (m_alignReference != null)
                {
                    return m_alignReference;
                }

                return m_forkAxis != null ? m_forkAxis : transform;
            }
        }

        public bool IsReady
        {
            get
            {
                EnsureNodesFromLegacy();
                return m_rowAxis != null && m_levelAxis != null && m_forkAxis != null;
            }
        }

        /// <summary>最近一次 MoveAlignToWorld 算出的目标 local 与 delta（供日志）。</summary>
        public Vector3 LastRowTargetLocal { get; private set; }
        public Vector3 LastLevelTargetLocal { get; private set; }
        public Vector3 LastForkTargetLocal { get; private set; }
        public Vector3 LastRowDeltaLocal { get; private set; }
        public Vector3 LastLevelDeltaLocal { get; private set; }
        public Vector3 LastForkDeltaLocal { get; private set; }
        public Vector3 LastTargetWorld { get; private set; }
        public StackerAxisMask LastMask { get; private set; }

        private void Awake()
        {
            EnsureNodesFromLegacy();
            EnsureRest();
        }

        /// <summary>回放可把场景里旧 JointController 交给驱动做节点 fallback。</summary>
        public void SetLegacyJointController(JointController controller)
        {
            if (controller == null)
            {
                return;
            }

            m_legacyJointController = controller;
            _legacyTried = false;
            EnsureNodesFromLegacy();
            EnsureRest();
        }

        public void EnsureNodesFromLegacy()
        {
            if (_legacyTried
                && m_rowAxis != null
                && m_levelAxis != null
                && m_forkAxis != null
                && m_legacyJointController == null)
            {
                return;
            }

            _legacyTried = true;
            if (m_legacyJointController == null)
            {
                m_legacyJointController = GetComponent<JointController>();
                if (m_legacyJointController == null)
                {
                    m_legacyJointController = GetComponentInChildren<JointController>(true);
                }
            }

            if (m_legacyJointController == null
                || m_legacyJointController.Joints == null
                || m_legacyJointController.Joints.Length < 3)
            {
                return;
            }

            var joints = m_legacyJointController.Joints;
            if (m_rowAxis == null && joints[0] != null)
            {
                m_rowAxis = joints[0].JointsNode;
            }

            if (m_levelAxis == null && joints[1] != null)
            {
                m_levelAxis = joints[1].JointsNode;
            }

            if (m_forkAxis == null && joints[2] != null)
            {
                m_forkAxis = joints[2].JointsNode;
            }

            if (joints[0] != null)
            {
                m_rowDir = joints[0].DirType;
            }

            if (joints[1] != null)
            {
                m_levelDir = joints[1].DirType;
            }

            if (joints[2] != null)
            {
                m_forkDir = joints[2].DirType;
            }
        }

        /// <summary>
        /// 把对齐参考点挪到 targetWorld。只有掩码里的轴会滑动，且每个轴只改自己的 Dir 分量。
        /// duration≤0 则瞬间到位。
        /// </summary>
        public bool MoveAlignToWorld(Vector3 targetWorld, float duration) =>
            MoveAlignToWorld(targetWorld, duration, StackerAxisMask.All);

        public bool MoveAlignToWorld(Vector3 targetWorld, float duration, StackerAxisMask mask)
        {
            if (mask == StackerAxisMask.None)
            {
                mask = StackerAxisMask.All;
            }

            if (!IsReady || !TryComputeLocalTargets(targetWorld, mask, out var rowTarget, out var levelTarget, out var forkTarget))
            {
                return false;
            }

            LastTargetWorld = targetWorld;
            LastMask = mask;
            LastRowTargetLocal = rowTarget;
            LastLevelTargetLocal = levelTarget;
            LastForkTargetLocal = forkTarget;
            LastRowDeltaLocal = rowTarget - m_rowAxis.localPosition;
            LastLevelDeltaLocal = levelTarget - m_levelAxis.localPosition;
            LastForkDeltaLocal = forkTarget - m_forkAxis.localPosition;

            _rowFree = (mask & StackerAxisMask.Row) != 0;
            _levelFree = (mask & StackerAxisMask.Level) != 0;
            _forkFree = (mask & StackerAxisMask.Fork) != 0;
            _rowFrom = ReadScalar(m_rowAxis, _rowRest, m_rowDir);
            _levelFrom = ReadScalar(m_levelAxis, _levelRest, m_levelDir);
            _forkFrom = ReadScalar(m_forkAxis, _forkRest, m_forkDir);
            _rowTo = ReadScalar(rowTarget, _rowRest, m_rowDir);
            _levelTo = ReadScalar(levelTarget, _levelRest, m_levelDir);
            _forkTo = ReadScalar(forkTarget, _forkRest, m_forkDir);

            if (duration <= 1e-6f)
            {
                ApplyScalars(_rowTo, _levelTo, _forkTo);
                _moving = false;
                return true;
            }

            ApplyScalars(_rowFrom, _levelFrom, _forkFrom);
            _moveDuration = duration;
            _moveElapsed = 0f;
            _moving = true;
            return true;
        }

        /// <summary>停在当前位置（打断插值）。</summary>
        public void StopMotion()
        {
            _moving = false;
        }

        /// <summary>立刻对齐到 targetWorld。</summary>
        public bool SnapAlignToWorld(Vector3 targetWorld) =>
            MoveAlignToWorld(targetWorld, 0f, StackerAxisMask.All);

        public bool SnapAlignToWorld(Vector3 targetWorld, StackerAxisMask mask) =>
            MoveAlignToWorld(targetWorld, 0f, mask);

        public Vector3 GetAlignWorldPosition() => AlignReference.position;

        /// <summary>货叉相对静止位的伸缩标量。0 表示收回。</summary>
        public float GetForkScalar()
        {
            EnsureRest();
            return ReadScalar(m_forkAxis, _forkRest, m_forkDir);
        }

        /// <summary>
        /// 只改货叉伸缩。不改排、层。进行中的插值也不会把货叉写回去。
        /// </summary>
        public void SetForkScalar(float scalar)
        {
            if (!IsReady)
            {
                return;
            }

            EnsureRest();
            _forkFrom = scalar;
            _forkTo = scalar;
            _forkFree = false;
            WriteScalar(m_forkAxis, _forkRest, m_forkDir, scalar);
        }

        /// <summary>货叉关节每增加 1 个标量，对齐点在世界上的位移。</summary>
        public bool TryGetForkAxisWorldVector(out Vector3 worldPerUnit)
        {
            worldPerUnit = default;
            if (!IsReady || !TryLocalBasis(m_forkDir, out var basis))
            {
                return false;
            }

            var parent = m_forkAxis.parent;
            worldPerUnit = parent != null ? parent.TransformVector(basis) : basis;
            return worldPerUnit.sqrMagnitude > 1e-10f;
        }

        private void Update()
        {
            if (!_moving)
            {
                return;
            }

            _moveElapsed += Time.deltaTime;
            var t = _moveDuration <= 1e-6f ? 1f : Mathf.Clamp01(_moveElapsed / _moveDuration);
            var row = _rowFree ? Mathf.Lerp(_rowFrom, _rowTo, t) : _rowFrom;
            var level = _levelFree ? Mathf.Lerp(_levelFrom, _levelTo, t) : _levelFrom;
            var fork = _forkFree ? Mathf.Lerp(_forkFrom, _forkTo, t) : _forkFrom;
            ApplyScalars(row, level, fork);
            if (t >= 1f)
            {
                _moving = false;
            }
        }

        /// <summary>
        /// 求各轴目标 local。掩码外的轴保持当前标量。不改场景姿态。
        /// </summary>
        public bool TryComputeLocalTargets(
            Vector3 targetWorld,
            out Vector3 rowTarget,
            out Vector3 levelTarget,
            out Vector3 forkTarget) =>
            TryComputeLocalTargets(targetWorld, StackerAxisMask.All,
                out rowTarget, out levelTarget, out forkTarget);

        public bool TryComputeLocalTargets(
            Vector3 targetWorld,
            StackerAxisMask mask,
            out Vector3 rowTarget,
            out Vector3 levelTarget,
            out Vector3 forkTarget)
        {
            rowTarget = default;
            levelTarget = default;
            forkTarget = default;
            if (!IsReady)
            {
                return false;
            }

            EnsureRest();
            if (mask == StackerAxisMask.None)
            {
                mask = StackerAxisMask.All;
            }

            var row = ReadScalar(m_rowAxis, _rowRest, m_rowDir);
            var level = ReadScalar(m_levelAxis, _levelRest, m_levelDir);
            var fork = ReadScalar(m_forkAxis, _forkRest, m_forkDir);

            var error = targetWorld - AlignReference.position;
            error -= RailSnapWorldDelta(m_rowAxis, _rowRest, m_rowDir, row);
            error -= RailSnapWorldDelta(m_levelAxis, _levelRest, m_levelDir, level);
            error -= RailSnapWorldDelta(m_forkAxis, _forkRest, m_forkDir, fork);

            if ((mask & StackerAxisMask.Row) != 0)
            {
                row += SlideAlong(m_rowAxis, m_rowDir, ref error);
            }

            if ((mask & StackerAxisMask.Level) != 0)
            {
                level += SlideAlong(m_levelAxis, m_levelDir, ref error);
            }

            if ((mask & StackerAxisMask.Fork) != 0)
            {
                fork += SlideAlong(m_forkAxis, m_forkDir, ref error);
            }

            rowTarget = OnRail(_rowRest, m_rowDir, row);
            levelTarget = OnRail(_levelRest, m_levelDir, level);
            forkTarget = OnRail(_forkRest, m_forkDir, fork);
            return true;
        }

        private void ApplyScalars(float row, float level, float fork)
        {
            WriteScalar(m_rowAxis, _rowRest, m_rowDir, row);
            WriteScalar(m_levelAxis, _levelRest, m_levelDir, level);
            WriteScalar(m_forkAxis, _forkRest, m_forkDir, fork);
        }

        private void EnsureRest()
        {
            if (m_rowAxis == null || m_levelAxis == null || m_forkAxis == null)
            {
                return;
            }

            if (!_restReady)
            {
                _rowRest = m_rowAxis.localPosition;
                _levelRest = m_levelAxis.localPosition;
                _forkRest = m_forkAxis.localPosition;
                _restReady = true;
            }

            var joints = m_legacyJointController != null ? m_legacyJointController.Joints : null;
            if (joints == null || joints.Length < 3)
            {
                return;
            }

            if (joints[0] != null && joints[0].JointsNode == m_rowAxis)
            {
                _rowRest = joints[0].ZeroState;
            }

            if (joints[1] != null && joints[1].JointsNode == m_levelAxis)
            {
                _levelRest = joints[1].ZeroState;
            }

            if (joints[2] != null && joints[2].JointsNode == m_forkAxis)
            {
                _forkRest = joints[2].ZeroState;
            }
        }

        /// <summary>
        /// 把当前标量收回到滑轨时，对齐点会跟着动多少。只在该轴是对齐点的祖先（或自身）时计入。
        /// </summary>
        private Vector3 RailSnapWorldDelta(Transform axis, Vector3 rest, JointDirType dir, float scalar)
        {
            if (!MovesAlign(axis))
            {
                return Vector3.zero;
            }

            var localDelta = OnRail(rest, dir, scalar) - axis.localPosition;
            if (localDelta.sqrMagnitude < 1e-12f)
            {
                return Vector3.zero;
            }

            var parent = axis.parent;
            return parent != null ? parent.TransformVector(localDelta) : localDelta;
        }

        /// <summary>
        /// 用本轴世界方向吃掉剩余误差上的投影，返回要追加的标量。轴向不动对齐点时返回 0。
        /// </summary>
        private float SlideAlong(Transform axis, JointDirType dir, ref Vector3 error)
        {
            if (!MovesAlign(axis) || !TryLocalBasis(dir, out var basis))
            {
                return 0f;
            }

            var parent = axis.parent;
            var world = parent != null ? parent.TransformVector(basis) : basis;
            var denom = world.sqrMagnitude;
            if (denom < 1e-10f)
            {
                return 0f;
            }

            var delta = Vector3.Dot(error, world) / denom;
            if (float.IsNaN(delta) || float.IsInfinity(delta))
            {
                return 0f;
            }

            error -= world * delta;
            return delta;
        }

        private bool MovesAlign(Transform axis)
        {
            if (axis == null)
            {
                return false;
            }

            var align = AlignReference;
            return align == axis || align.IsChildOf(axis);
        }

        private static float ReadScalar(Transform axis, Vector3 rest, JointDirType dir)
        {
            if (axis == null)
            {
                return 0f;
            }

            return ReadScalar(axis.localPosition, rest, dir);
        }

        private static float ReadScalar(Vector3 local, Vector3 rest, JointDirType dir)
        {
            if (!TryLocalBasis(dir, out var basis))
            {
                return 0f;
            }

            var index = AxisIndex(basis);
            return (local[index] - rest[index]) * basis[index];
        }

        private static Vector3 OnRail(Vector3 rest, JointDirType dir, float scalar)
        {
            if (!TryLocalBasis(dir, out var basis))
            {
                return rest;
            }

            var index = AxisIndex(basis);
            rest[index] += scalar * basis[index];
            return rest;
        }

        private static void WriteScalar(Transform axis, Vector3 rest, JointDirType dir, float scalar)
        {
            if (axis == null)
            {
                return;
            }

            axis.localPosition = OnRail(rest, dir, scalar);
        }

        /// <summary>正方向为单位轴，反方向（IX/IY/IZ）为单位轴取反。分量值就是标量的符号。</summary>
        private static bool TryLocalBasis(JointDirType dir, out Vector3 basis)
        {
            switch (dir)
            {
                case JointDirType.X:
                    basis = Vector3.right;
                    return true;
                case JointDirType.IX:
                    basis = Vector3.left;
                    return true;
                case JointDirType.Y:
                    basis = Vector3.up;
                    return true;
                case JointDirType.IY:
                    basis = Vector3.down;
                    return true;
                case JointDirType.Z:
                    basis = Vector3.forward;
                    return true;
                case JointDirType.IZ:
                    basis = Vector3.back;
                    return true;
                default:
                    basis = default;
                    return false;
            }
        }

        private static int AxisIndex(Vector3 basis)
        {
            if (basis.x != 0f)
            {
                return 0;
            }

            if (basis.y != 0f)
            {
                return 1;
            }

            return 2;
        }
    }
}
