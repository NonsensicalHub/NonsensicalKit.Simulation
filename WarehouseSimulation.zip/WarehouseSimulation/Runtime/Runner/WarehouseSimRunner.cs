using System;
using System.Collections;
using NaughtyAttributes;
using UnityEngine;
using NonsensicalKit.Simulation.WarehouseSimulation.Allocation;
using NonsensicalKit.Simulation.WarehouseSimulation.Config;
using NonsensicalKit.Simulation.WarehouseSimulation.Model;
using NonsensicalKit.Simulation.WarehouseSimulation.Playback;
using NonsensicalKit.Simulation.WarehouseSimulation.Simulation;

namespace NonsensicalKit.Simulation.WarehouseSimulation.Runtime
{
    /// <summary>场景入口：运行仓库仿真（入库/出库等）并写入回放数据；场景可视由回放控制器单独驱动。</summary>
    public class WarehouseSimRunner : MonoBehaviour
    {
        [SerializeField, Label("仿真场景")]
        private WarehouseSimScenario m_scenario;

        [SerializeField, Label("网格配置")]
        [Tooltip("仓库列表留空时，这是唯一 0 号库的网格。绑定资产填写了仓库列表后，以列表里每项自己的网格为准。")]
        private WarehouseGridConfig m_grid = new();

        [SerializeField, Label("回放事件源（可选）")]
        private SimPlaybackEventSource m_playbackEventSource;

        [SerializeField, Label("输出摘要到控制台")]
        private bool m_logSummaryToConsole = true;

        [SerializeField, Label("输出关键步骤日志")]
        private bool m_logKeySteps = true;

        [SerializeField, Label("输出详细流水日志")]
        private bool m_logVerboseSteps;

        [SerializeField, Label("记录回放与子任务")]
        [Tooltip("关闭后仅保留汇总统计，大批量仿真时可显著提速。")]
        private bool m_recordPlaybackAndSubTasks = true;

        [SerializeField, Label("收集墙钟性能剖析")]
        [Tooltip("开启后按阶段统计 CPU 墙钟耗时，用于定位仿真热点；结果写入 SimRunResult 并在控制台摘要输出。")]
        private bool m_collectWallClockProfile;

        [SerializeField, Label("导出目录（留空=StreamingAssets/SimulationExports）")]
        private string m_exportDirectory;

                /// <summary>当前任务若来自 JSON，记录其存档 Id（不含扩展名）。</summary>
        private string _scenarioJsonId;

        /// <summary>当前任务的硬件 Resources 路径（导出 JSON 时写入）。</summary>
        private string _hardwareResourcesPath;

        /// <summary>当前任务的策略 Resources 路径（可选）。</summary>
        private string _strategyResourcesPath;

        private SimRunResult _lastResult;
        private Coroutine _runCoroutine;
        private Coroutine _exportCoroutine;
        private bool _isRunning;
        private bool _isExporting;

        public SimRunResult LastResult => _lastResult;
        public StackerWarehouseSimulator LastSimulator { get; private set; }
        public bool IsRunning => _isRunning;
        public bool IsExporting => _isExporting;

        /// <summary>后台仿真心跳：已等待时间之外的当前阶段、仿真时刻和完成数。</summary>
        public string LiveRunStatus { get; private set; }

        /// <summary>已完成入库任务的货物数量。仿真空闲时为 0。</summary>
        public int LiveInboundCompleted { get; private set; }

        /// <summary>本轮计划入库货物总数。仿真空闲时为 0。</summary>
        public int LiveInboundTarget { get; private set; }

        internal void SetLiveRunStatus(string text, int inboundCompleted, int inboundTarget)
        {
            LiveRunStatus = text;
            LiveInboundCompleted = inboundCompleted;
            LiveInboundTarget = inboundTarget;
        }

        /// <summary>当前仿真任务。空闲时可由界面修改，下一次运行读取这里的配置。</summary>
        public WarehouseSimScenario Scenario => m_scenario;

                /// <summary>若当前任务来自 JSON 存档，为其 Id；否则为空。</summary>
        public string ScenarioJsonId => _scenarioJsonId;

        public string HardwareResourcesPath =>
            string.IsNullOrWhiteSpace(_hardwareResourcesPath)
                ? WarehouseSimScenarioJson.DefaultHardwareResourcesPath
                : _hardwareResourcesPath;

        public string StrategyResourcesPath => _strategyResourcesPath;

        /// <summary>切换当前任务配置（运行中不可改）。可传入运行时 CreateInstance 的 Scenario。</summary>
        public void SetScenario(WarehouseSimScenario scenario, string jsonId = null, string hardwareResourcesPath = null, string strategyResourcesPath = null)
        {
            if (_isRunning)
            {
                Debug.LogWarning("[WarehouseSimulation] 仿真运行中，无法切换任务配置。", this);
                return;
            }

            if (scenario == null)
            {
                Debug.LogError("[WarehouseSimulation] SetScenario：scenario 为空。", this);
                return;
            }

            m_scenario = scenario;
            _scenarioJsonId = string.IsNullOrWhiteSpace(jsonId) ? null : WarehouseSimScenarioJson.SanitizeId(jsonId);
            if (!string.IsNullOrWhiteSpace(hardwareResourcesPath))
            {
                _hardwareResourcesPath = hardwareResourcesPath.Trim().Replace('\\', '/');
            }

            if (strategyResourcesPath != null)
            {
                _strategyResourcesPath = string.IsNullOrWhiteSpace(strategyResourcesPath)
                    ? null
                    : strategyResourcesPath.Trim().Replace('\\', '/');
            }
        }

        /// <summary>从 JSON DTO 构建运行时 Scenario 并设为当前任务。</summary>
        public bool ApplyScenarioDto(WarehouseSimScenarioDto dto, out string error)
        {
            error = null;
            if (_isRunning)
            {
                error = "仿真运行中，无法切换任务配置。";
                return false;
            }

            var scenario = WarehouseSimScenarioJson.ToRuntimeScenario(dto, out error);
            if (scenario == null)
            {
                return false;
            }

            SetScenario(scenario, dto.Id, dto.HardwareResourcesPath, dto.StrategyResourcesPath);
            return true;
        }

        /// <summary>把当前 Scenario 导出为 DTO（用于保存 JSON）。</summary>
        public WarehouseSimScenarioDto ExportCurrentScenarioDto(string idOverride = null)
        {
            if (m_scenario == null)
            {
                return null;
            }

            var id = !string.IsNullOrWhiteSpace(idOverride)
                ? idOverride
                : (!string.IsNullOrWhiteSpace(_scenarioJsonId) ? _scenarioJsonId : m_scenario.name);
            return WarehouseSimScenarioJson.FromScenario(
                m_scenario,
                id,
                HardwareResourcesPath,
                _strategyResourcesPath);
        }
        [Button("运行仿真")]
        public void RunSimulation()
        {
            if (_isRunning)
            {
                Debug.LogWarning("[WarehouseSimulation] 上一次仿真仍在后台执行。", this);
                return;
            }

            if (m_scenario == null)
            {
                Debug.LogError("[WarehouseSimulation] 请指定 WarehouseSimScenario。", this);
                return;
            }

            if (_runCoroutine != null)
            {
                StopCoroutine(_runCoroutine);
            }

            _runCoroutine = StartCoroutine(RunSimulationCoroutine());
        }

        private IEnumerator RunSimulationCoroutine()
        {
            _isRunning = true;
            LiveRunStatus = null;
            LiveInboundCompleted = 0;
            LiveInboundTarget = 0;
            SimRunBackgroundRun.Outcome outcome = null;
            try
            {
                yield return SimRunBackgroundRun.Run(
                    this,
                    m_scenario,
                    m_grid,
                    BuildRunOptions(),
                    m_logKeySteps,
                    m_logVerboseSteps,
                    onComplete: o => outcome = o);

                if (!SimRunBackgroundRun.TryApplyOutcome(outcome, out var simulator, out var result))
                {
                    if (outcome?.Error != null)
                    {
                        Debug.LogError($"[WarehouseSimulation] 仿真失败：{outcome.Error.Message}", this);
                    }
                    else
                    {
                        Debug.LogError("[WarehouseSimulation] 仿真失败：未收到有效结果。", this);
                    }

                    LastSimulator = null;
                    _lastResult = null;
                    yield break;
                }

                LastSimulator = simulator;
                _lastResult = result;

                if (_lastResult.OccupancyConflicts != null && _lastResult.OccupancyConflicts.Count > 0)
                {
                    Debug.LogWarning(
                        $"[WarehouseSimulation] 节点占用自检 {_lastResult.OccupancyConflicts.Count} 处冲突，" +
                        "请导出报告后在调试 Markdown 中查看明细。",
                        this);
                }

                if (_lastResult.SegmentCoOccupancies != null && _lastResult.SegmentCoOccupancies.Count > 0)
                {
                    Debug.LogWarning(
                        $"[WarehouseSimulation] 路段同时占用自检 {_lastResult.SegmentCoOccupancies.Count} 处，" +
                        "请导出报告后在调试 Markdown 中查看明细。",
                        this);
                }

                if (_lastResult.SubTaskTimelineIssues != null && _lastResult.SubTaskTimelineIssues.Count > 0)
                {
                    Debug.LogWarning(
                        $"[WarehouseSimulation] 子任务时间轴自检 {_lastResult.SubTaskTimelineIssues.Count} 处问题，" +
                        "请导出报告后在调试 Markdown 中查看明细。",
                        this);
                }

                if (m_logSummaryToConsole)
                {
                    WarehouseSimulationService.LogSummary(_lastResult);
                }

                if (m_playbackEventSource != null)
                {
                    var initialSlots = SlotAllocatorFactory.BuildInitialOccupiedSlots(m_scenario, m_grid);
                    m_playbackEventSource.AttachRunTimeline(
                        LastSimulator.LastPlaybackEvents,
                        LastSimulator.LastSubTasks,
                        initialSlots,
                        m_grid,
                        m_scenario.ResolvedHardwareBindings,
                        _lastResult.TotalSimSeconds);
                }

            }
            finally
            {
                _isRunning = false;
                LiveRunStatus = null;
                LiveInboundCompleted = 0;
                LiveInboundTarget = 0;
                _runCoroutine = null;
            }
        }

        [Button("导出可回放 HTML 报告")]
        public void ExportLastRunResult()
        {
            if (_isExporting)
            {
                Debug.LogWarning("[WarehouseSimulation] 上一次报告导出仍在后台执行。", this);
                return;
            }

            if (LastSimulator == null || _lastResult == null)
            {
                Debug.LogError("[WarehouseSimulation] 导出中止：请先运行仿真。", this);
                return;
            }

            if (_exportCoroutine != null)
            {
                StopCoroutine(_exportCoroutine);
            }

            _exportCoroutine = StartCoroutine(ExportLastRunResultCoroutine());
        }

        private IEnumerator ExportLastRunResultCoroutine()
        {
            _isExporting = true;
            SimRunBackgroundExport.Outcome outcome = null;
            try
            {
                var initialSlots = m_playbackEventSource != null
                    ? m_playbackEventSource.InitialOccupiedSlots
                    : null;
                yield return SimRunBackgroundExport.Run(
                    this,
                    m_scenario,
                    LastSimulator,
                    _lastResult,
                    string.IsNullOrWhiteSpace(m_exportDirectory) ? null : m_exportDirectory,
                    onComplete: o => outcome = o,
                    initialOccupiedSlots: initialSlots,
                    scenarioDisplayName: !string.IsNullOrWhiteSpace(_scenarioJsonId)
                        ? _scenarioJsonId
                        : m_scenario != null ? m_scenario.name : null);

                if (outcome?.Error != null)
                {
                    Debug.LogError($"[WarehouseSimulation] 导出失败：{outcome.Error.Message}", this);
                    yield break;
                }

                _lastResult.DebugReportPath = outcome.DebugReportPath;
                Debug.Log(
                    $"[WarehouseSimulation] 已导出可回放报告：{outcome.HtmlPath}\n" +
                    $"  调试信息报告：{outcome.DebugReportPath}",
                    this);
            }
            finally
            {
                _isExporting = false;
                _exportCoroutine = null;
            }
        }

        private SimRunOptions? BuildRunOptions() => new()
        {
            RecordPlaybackAndSubTasks = m_recordPlaybackAndSubTasks,
            CollectWallClockProfile = m_collectWallClockProfile,
        };

        /// <summary>从可回放 HTML 报告加载时间轴到事件源，并可供回放控制器播放。</summary>
        public bool TryLoadReplayHtml(string path, out string error, out SimReplayHtmlCodec.Payload payload)
        {
            error = null;
            payload = null;
            if (_isRunning || _isExporting)
            {
                error = "仿真或导出进行中，无法加载回放。";
                return false;
            }

            if (m_playbackEventSource == null)
            {
                error = "场景未配置回放事件源。";
                return false;
            }

            if (!SimReplayHtmlCodec.TryLoadFromFile(path, out payload, out error))
            {
                return false;
            }

            m_scenario?.EnsureResolvedOnMainThread();
            m_playbackEventSource.SetTimeline(
                payload.Events,
                payload.SubTasks,
                payload.InitialOccupiedSlots,
                m_grid,
                m_scenario != null ? m_scenario.ResolvedHardwareBindings : null,
                payload.TotalSimSeconds);

            // 用摘要填一份轻量结果，方便 UI 显示「有结果」。
            _lastResult = new SimRunResult
            {
                Success = true,
                Message = string.IsNullOrEmpty(payload.Message)
                    ? $"已从文件加载回放：{System.IO.Path.GetFileName(path)}"
                    : payload.Message,
                TargetJobCount = payload.TargetJobCount,
                CompletedJobCount = payload.CompletedJobCount,
                TotalSimSeconds = payload.TotalSimSeconds,
                ThroughputPerHour = payload.ThroughputPerHour,
            };
            LastSimulator = null;

            Debug.Log(
                $"[WarehouseSimulation] 已加载可回放报告：{path}\n" +
                $"  子任务 {payload.SubTasks?.Length ?? 0}，事件 {payload.Events?.Length ?? 0}，" +
                $"仿真时长 {payload.TotalSimSeconds:F1}s",
                this);
            return true;
        }

        [Button("打开报告目录")]
        public void OpenReportDirectory()
        {
            try
            {
                WarehouseSimReportDirectory.Open(
                    string.IsNullOrWhiteSpace(m_exportDirectory) ? null : m_exportDirectory);
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[WarehouseSimulation] 打开报告目录失败：{ex.Message}", this);
            }
        }
    }
}
